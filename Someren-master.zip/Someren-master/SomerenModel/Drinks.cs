﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Drinks
    {
        public int DrinkId { get; set; }
        public string DrinkName { get; set; }
        public int DrinkPrice { get; set; }
        public int DrinkStock { get; set; }
    }
}
