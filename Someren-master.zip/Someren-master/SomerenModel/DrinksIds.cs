﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public enum DrinkIds
    {
        Bier, RodeWijn, WitteWijn, Shotje, Fanta, Cola, SevenUp, IceTea
    }
}
