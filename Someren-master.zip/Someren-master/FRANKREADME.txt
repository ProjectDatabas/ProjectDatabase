# ProjectDatabase

# Github Repo Link:
https://github.com/ProjectDatabas/ProjectDatabase

-- Week 1
  
    Opdracht Rolverdeling:

    Niet van toepassing...

--

-- Week 2
 
    Opdracht Rolverdeling:

    Variant A Student:
    Jesper van der Ven

    Variant B Lecturers:
    Luke Huisman

--

-- Week 3

    Opdracht Rolverdeling:

    Variant A Drink supplies:
    Luke Huisman

    Variant B Cash Register:
    Jesper van der Ven

--
-- Week 4

    Opdracht Rolverdeling:

    Variant A List of Activities:
    Jesper van der Ven

    Variant B Activity Supervisors:
    Luke Huisman
    
--
